<?php

define('USER_DOMAIN', 'demo.lexir.rocks');
# Url to redirect to when solving. Below is just an example, I recommend
# putting a LinkVertise on top of it, so that way you can earn some money from ADs.
define('USER_FINISH', 'https://' . USER_DOMAIN . '/Generate.php?solve=1');

# Database Configuration
define('DB_HOST', 'database host');
define('DB_USER', 'database user');
define('DB_PASSWORD', 'database password');
define('DB_NAME', 'database name');